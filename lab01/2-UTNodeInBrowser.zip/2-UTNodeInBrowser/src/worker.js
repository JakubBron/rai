function Worker(name) {
	this.Introduce = function() { return "Helloooo I'm " + name; }
		this.DoJob = function(task) { return "Worker " + name + " does " + task; }
} 


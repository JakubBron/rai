module.exports = function() {
	this.Hello = function(name) { return "Helloooo to " + name; }
}

